package org.gradle.tests29;

import org.junit.Test;

public class Test29_7 {
    @Test
    public void myTest() throws Exception {
        Thread.sleep(5);
    }
}