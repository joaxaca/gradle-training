package org.gradle.tests24;

import org.junit.Test;

public class Test24_3 {
    @Test
    public void myTest() throws Exception {
        Thread.sleep(5);
    }
}