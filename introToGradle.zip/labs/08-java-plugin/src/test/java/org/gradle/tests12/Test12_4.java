package org.gradle.tests12;

import org.junit.Test;

public class Test12_4 {
    @Test
    public void myTest() throws Exception {
        Thread.sleep(5);
    }
}