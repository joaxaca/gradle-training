package org.gradle.tests7;

import org.junit.Test;

public class Test7_8 {
    @Test
    public void myTest() throws Exception {
        Thread.sleep(5);
    }
}