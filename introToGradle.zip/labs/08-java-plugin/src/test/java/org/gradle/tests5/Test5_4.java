package org.gradle.tests5;

import org.junit.Test;

public class Test5_4 {
    @Test
    public void myTest() throws Exception {
        Thread.sleep(5);
    }
}