package org.gradle.tests0;

import org.junit.Test;

public class Test0_8 {
    @Test
    public void myTest() throws Exception {
        Thread.sleep(5);
    }
}