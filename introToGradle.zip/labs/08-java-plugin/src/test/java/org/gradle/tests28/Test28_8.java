package org.gradle.tests28;

import org.junit.Test;

public class Test28_8 {
    @Test
    public void myTest() throws Exception {
        Thread.sleep(5);
    }
}