package org.gradle.tests9;

import org.junit.Test;

public class Test9_1 {
    @Test
    public void myTest() throws Exception {
        Thread.sleep(5);
    }
}