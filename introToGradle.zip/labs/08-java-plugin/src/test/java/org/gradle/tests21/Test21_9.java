package org.gradle.tests21;

import org.junit.Test;

public class Test21_9 {
    @Test
    public void myTest() throws Exception {
        Thread.sleep(5);
    }
}