package org.company;

import org.springframework.core.SpringVersion;

public class Program {
  
    public static void main(String[] args) {
        System.out.println("Welcome!");
    }
  
}